FactoryBot.define do
  factory :task_membership do
    task nil
    standup nil
  end
end

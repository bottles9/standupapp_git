FactoryBot.define do
  factory :team_membership do
    team
    user
  end
end

FactoryBot.define do
  factory :integration do
    account nil
    type ""
    settings ""
  end
end

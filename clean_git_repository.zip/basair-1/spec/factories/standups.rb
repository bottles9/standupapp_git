FactoryBot.define do
  factory :standup do
    user
    standup_date "2017-04-25"
  end
end

FactoryBot.define do
  factory :account do
    name "MyString"
    addr1 "MyString"
    addr2 "MyString"
    city "MyString"
    state "MyString"
    zip "MyString"
    country "MyString"
    hash_id "MyString"
    settings ""
    subscription
  end
end

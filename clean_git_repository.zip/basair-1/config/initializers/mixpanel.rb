TRACKER = Mixpanel::Tracker.new(ENV['MIXPANEL_TOKEN'])

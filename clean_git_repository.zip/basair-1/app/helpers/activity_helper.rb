module ActivityHelper
end

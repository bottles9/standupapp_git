class StripeWebhook < ApplicationRecord
end

module Integrations
  class Github < Integration
  end
end

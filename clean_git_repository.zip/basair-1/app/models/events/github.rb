module Events
  class Github < Event
  end
end

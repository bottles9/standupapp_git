class Integration < ApplicationRecord
  belongs_to :account
end

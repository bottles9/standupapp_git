class Blocker < Task

end
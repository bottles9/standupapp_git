class Todo < Task

end
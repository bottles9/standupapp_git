class AccountsController < ApplicationController
  load_and_authorize_resource :find_by => :hash_id

  def new
    redirect_to root_path unless current_user.account.nil?
    @account = Account.new
  end

  def create
    @account = Account.new(account_params)
    result = NewRegistrationService.(account: @account, user: current_user, plan: params[:plan])
    if result.success?
      redirect_to root_path, success: 'Your account has been created!'
    else
      @account = result.account
      render :new
    end
  end

  private
  # Never trust parameters from the scary internet, only allow the white list through.
    def account_params
      params.require(:account).permit(:name, :addr1, :addr2, :city, :state, :zip, :country)
    end
end
